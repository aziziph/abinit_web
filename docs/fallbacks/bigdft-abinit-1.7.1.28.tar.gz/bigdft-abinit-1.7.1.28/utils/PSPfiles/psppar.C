Goedecker-Teter-Hutter  Thu May  9 12:19:55 EDT 1996
6   4   960509                     zatom,zion,pspdat
2   1   0    0    2001    0.       pspcod,pspxc,lmax,lloc,mmax,r2well
0.3464730 -8.5753285 1.2341279 0 0 rloc, c1, c2, c3, c4
.3045228 9.5341929 0               rs, h1s, h2s
0 0                                rp, h1p
1.482313   .25    
1.46              rcutoff, rloc
