Goedecker pseudopotential for C
    6   4  070301 zatom,zion,pspdat
10 11  1 2 2001 0  pspcod,pspxc,lmax,lloc,mmax,r2well
     0.33847124    2    -8.80367398     1.33921085                                  rloc nloc c1 c2
    2                                                                               nnonloc
     0.30257575    1     9.62248665                                                 rs ns hs11
     0.29150694    1     0.00000000                                                 rp np hp11
                         0.00207319                                                       kp11

