typedef struct param_t{
    double *a_d, *b_d, *c_d;
    int N;
} param_t;
